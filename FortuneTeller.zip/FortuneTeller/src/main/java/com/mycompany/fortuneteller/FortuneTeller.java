/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fortuneteller;

import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Matete Magomane
 */
public class FortuneTeller {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userResponse;

        System.out.println("🔮 Welcome to the Fortune Teller App! 🔮");

        do {
            printFortune();

            System.out.print("\nWould you like another fortune? (yes/no): ");
            userResponse = scanner.nextLine().trim().toLowerCase();

        } while (userResponse.equals("yes"));

        System.out.println("\nThanks for playing! Remember: you’re still one compile away from greatness. 💫");
        scanner.close();
    }

    public static void printFortune() {
        String[] fortunes = {
            "You're doing better than your browser history suggests.",
            "The bug is not a bug—it's a feature of chaos.",
            "Your future holds success... and maybe pizza.",
            "Today is the perfect day to Google that error.",
            "Someone out there is jealous of your code—even if it doesn’t compile.",
            "Don’t worry, even senior devs forget semicolons.",
            "You will find love. Just not in Stack Overflow comments.",
            "The force is strong with your logic today.",
            "You’re one keystroke away from genius.",
            "Debugging is just an extreme sport of the mind. You're winning."
        };

        Random rand = new Random();
        int index = rand.nextInt(fortunes.length);
        System.out.println("\n✨ Your Fortune: " + fortunes[index]);
    }
}

